package ru.leningrad.rp;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String GAME_URL = "https://www.roblox.com/games/86706967486022";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12,12,12));
        getWindow().setNavigationBarColor(Color.BLACK);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(28, 32, 28, 32);
        page.setBackgroundColor(Color.rgb(12,12,12));

        TextView eyebrow = new TextView(this);
        eyebrow.setText("РОЛЕВАЯ ИГРА В ROBLOX");
        eyebrow.setTextColor(Color.rgb(220,55,55));
        eyebrow.setTextSize(13);
        eyebrow.setLetterSpacing(0.15f);
        eyebrow.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("ЛЕНИНГРАД\nRP");
        title.setTextColor(Color.WHITE);
        title.setTextSize(42);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        title.setGravity(Gravity.CENTER);
        title.setLineSpacing(0, 0.95f);

        TextView subtitle = new TextView(this);
        subtitle.setText("ТВОЯ ИСТОРИЯ НАЧИНАЕТСЯ ЗДЕСЬ");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 18, 0, 42);

        TextView play = new TextView(this);
        play.setText("ИГРАТЬ");
        play.setTextColor(Color.WHITE);
        play.setTextSize(18);
        play.setTypeface(Typeface.DEFAULT_BOLD);
        play.setGravity(Gravity.CENTER);
        play.setBackgroundColor(Color.rgb(174, 25, 32));
        play.setPadding(36, 18, 36, 18);
        play.setOnClickListener(v -> openGame());

        TextView footer = new TextView(this);
        footer.setText("ОТКРОЕТСЯ ЧЕРЕЗ ROBLOX");
        footer.setTextColor(Color.GRAY);
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, 28, 0, 0);

        page.addView(eyebrow);
        page.addView(title);
        page.addView(subtitle);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        buttonParams.setMargins(0, 0, 0, 0);
        page.addView(play, buttonParams);
        page.addView(footer);
        setContentView(page);
    }

    private void openGame() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(GAME_URL));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть Roblox. Установи приложение Roblox.", Toast.LENGTH_LONG).show();
        }
    }
}
